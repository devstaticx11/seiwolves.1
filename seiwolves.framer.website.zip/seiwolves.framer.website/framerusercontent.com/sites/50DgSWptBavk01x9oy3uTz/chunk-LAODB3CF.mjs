import{B as a,D as o}from"./chunk-JSNBFHC6.mjs";var r="default"in o?a:o,t={},e=r;t.createRoot=e.createRoot;t.hydrateRoot=e.hydrateRoot;var s=t.createRoot,f=t.hydrateRoot;export{s as a,f as b};
//# sourceMappingURL=chunk-LAODB3CF.mjs.map
